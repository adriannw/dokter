package com.example.springbootmysqldemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootmysqldemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
