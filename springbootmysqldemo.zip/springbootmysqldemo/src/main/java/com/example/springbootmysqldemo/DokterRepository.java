package com.example.springbootmysqldemo;

import org.springframework.data.repository.CrudRepository;

public interface DokterRepository extends CrudRepository<dokter, Integer> {
}



