package com.example.springbootmysqldemo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
public class HelloWorldController {

    @Autowired
    DokterService dokterService;

    //@RequestMapping("/dokter")
   // public List numberOfDokter() {

   //     return dokterService.dokterDetails();
   // }

   // @RequestMapping("/dokter/{id}")
   // public List numberOfDokter(@PathVariable("id") int id) {

   //     return dokterService.dokterDetailsById(id);
   // }

    @RequestMapping(method = RequestMethod.POST, value = "/dokter")
    public void insertDokter(@RequestBody dokter dok) {

        dokterService.insertDokterDetails(dok);
    }

    @RequestMapping(method = RequestMethod.GET, value ="/dokter")
    public List readDokter() {

        return dokterService.readDokterDetails();
    }

    @RequestMapping(method = RequestMethod.GET, value ="/dokter/{id}")
    public Optional< dokter > readDokterbyId(@PathVariable("id") int id) {

        return dokterService.readDokterDetailsById(id);
    }


}



