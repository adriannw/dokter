package com.example.springbootmysqldemo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class DokterService {

    @Autowired
   DokterRepository dokterRepository;

    public List dokterDetails() {

        List dokterList = new ArrayList<>();

        dokter dokter1 = new dokter(1, "adrian", "gula darah");
        dokter dokter2 = new dokter(2, "adi", "gula puasa");
        dokterList.add(dokter1);
        dokterList.add(dokter2);


        return dokterList;
    }

    public List dokterDetailsById(int id) {
        List<dokter> dokterById = new ArrayList<>();
        List<dokter> dokterList = dokterDetails();
        for (dokter dok : dokterList) {
            if (dok.getId_pasien() == id) {
                dokterById.add(dok);
            }
        }
        return dokterById;
    }

    public void insertDokterDetails(dokter dok) {
        dokterRepository.save(dok);
    }

    public List readDokterDetails() {
        List dokterList = (List) dokterRepository.findAll();
        return dokterList;
    }

    public Optional < dokter > readDokterDetailsById(int id) {
        Optional<dokter> dokterList = dokterRepository.findById(id);
        return dokterList;
    }
}
