package com.example.springbootmysqldemo;


import jakarta.persistence.Entity;
//has no identifier (every '@Entity' class must declare or inherit at least one '@Id' or '@EmbeddedId' property
//import org.springframework.data.annotation.Id;
import jakarta.persistence.Id;

@Entity
public class dokter {
    @Id
    int id_pasien;
    String nama_dokter;
    String status_pemeriksaan;


public dokter(){


}

    public dokter(int id_pasien,String nama_dokter,String nama_pemeriksaan ){
    this.id_pasien=id_pasien;
    this.nama_dokter=nama_dokter;
    this.status_pemeriksaan=nama_pemeriksaan;

    }

public int getId_pasien() {
    return id_pasien;
}

public void setId_pasien(int id_pasien) {
    this.id_pasien = id_pasien;
}

public String getNama_dokter() {
    return nama_dokter;
}

public void setNama_dokter(String nama_dokter) {
    this.nama_dokter = nama_dokter;
}


public String getStatus_pemeriksaan() {
  return status_pemeriksaan;

}

public void setStatus_pemeriksaan(String nama_pemeriksaan) {
    this.status_pemeriksaan = nama_pemeriksaan;
}

}

